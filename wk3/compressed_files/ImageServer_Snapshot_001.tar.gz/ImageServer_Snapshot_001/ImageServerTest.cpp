
#include "ImageServer.h"

// PManandhar note: not preferred, used for demo
// or short files
using namespace LMFocusStack;

int main(int argc, char ** argv) {

	ImageServer server(argc, argv);


	return 0;

}

