
#include "ImageServer.h"

// example of a namespace alias
namespace FS = LMFocusStack;

FS::ImageServer::ImageServer(int argc, char ** argv) {

}

int FS::ImageServer::StartServer() {
	return 0;
}

